# TODO 输入定位词列表检查列表
input_check_keyword_need=[
    "Args","输入","Input","Features"
]
# TODO 输入默认结构定位词列表
input_check_keyword_default=[
    "_summary_","_type_","_description_"
]

# TODO header检查行数
header_check_count =15